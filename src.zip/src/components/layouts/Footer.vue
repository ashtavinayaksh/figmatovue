<template>
  <div class="container-fluid" style="background-color: black;height: 450px;" >
    <h5 class="text-center workTitle">
      GET IDEAS IN YOUR INBOX TO GROW YOUR BRAND
    </h5>
    <input class="text-center" type="text"/>
  </div>
</template>

<script>
import "@/assets/scss/style.scss";

export default {};
</script>

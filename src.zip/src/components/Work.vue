<template>
  <div class="container-fluid bg-black pb-5">
    <h1 class="work-title">WORK</h1>
    <div class="row col-12">
      <div class="col-4">
        <img class="work-img" src="../assets/imgpsh_fullsize_anim (6).png" />
        <h5 class="workTitle mt-4">Digital Experience</h5>
        <h6 class="workTitle">Zenteiq</h6>
      </div>
      <div class="col-4">
        <img class="work-img" src="../assets/imgpsh_fullsize_anim (9).png" />
        <h5 class="workTitle mt-4">Package Design</h5>
        <h6 class="workTitle">Vaishnavi Coffee</h6>
      </div>
      <div class="col-4">
        <img class="work-img" src="../assets/imgpsh_fullsize_anim (7).png" />
        <h5 class="workTitle mt-4">Brand Identity</h5>
        <h6 class="workTitle">NLF</h6>
      </div>
    </div>
  </div>
</template>
<script>
export default {};
</script>
<style scoped>
.bg-black {
  background: black;
}
.work-img{width:100%;}
.work-title {
  color: white;
  margin-left: 10px;
  font-size: 7.2rem;
  margin-top: -35px;
}
</style>
